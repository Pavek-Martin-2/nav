@echo off
del "_TREE_folder_testovaci.txt"
sleep 1
date /t > "E:\_UPLOAD\nav\testovaci\_TREE_folder_testovaci.txt"
time /t >> "E:\_UPLOAD\nav\testovaci\_TREE_folder_testovaci.txt"
tree /F /A "E:\_UPLOAD\nav\testovaci\" >> "E:\_UPLOAD\nav\testovaci\_TREE_folder_testovaci.txt"
@echo on
REM pause
